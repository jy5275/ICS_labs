/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_450(unsigned *p)
{
    *p = 3351742792U;
}

void setval_349(unsigned *p)
{
    *p = 2425378840U;
}

unsigned getval_485()
{
    return 3281031248U;
}

void setval_298(unsigned *p)
{
    *p = 2425379053U;
}

unsigned addval_197(unsigned x)
{
    return x + 3284633928U;
}

void setval_173(unsigned *p)
{
    *p = 2423820123U;
}

void setval_200(unsigned *p)
{
    *p = 2496104776U;
}

void setval_437(unsigned *p)
{
    *p = 3347663073U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_110(unsigned x)
{
    return x + 2425408153U;
}

void setval_455(unsigned *p)
{
    *p = 3526934921U;
}

void setval_201(unsigned *p)
{
    *p = 3385117321U;
}

void setval_365(unsigned *p)
{
    *p = 3674789513U;
}

void setval_204(unsigned *p)
{
    *p = 2425411213U;
}

void setval_120(unsigned *p)
{
    *p = 3252717896U;
}

void setval_285(unsigned *p)
{
    *p = 3767093959U;
}

void setval_412(unsigned *p)
{
    *p = 3677935233U;
}

unsigned addval_218(unsigned x)
{
    return x + 3378561417U;
}

void setval_255(unsigned *p)
{
    *p = 2428570031U;
}

unsigned getval_122()
{
    return 2447411528U;
}

void setval_462(unsigned *p)
{
    *p = 2425405833U;
}

unsigned addval_125(unsigned x)
{
    return x + 3523267209U;
}

unsigned getval_150()
{
    return 3223374473U;
}

unsigned getval_155()
{
    return 3252062625U;
}

unsigned addval_144(unsigned x)
{
    return x + 2425405865U;
}

unsigned addval_479(unsigned x)
{
    return x + 3352725943U;
}

unsigned addval_160(unsigned x)
{
    return x + 3224944905U;
}

unsigned getval_426()
{
    return 3281043865U;
}

unsigned getval_327()
{
    return 3221280393U;
}

unsigned addval_484(unsigned x)
{
    return x + 2425471369U;
}

unsigned addval_315(unsigned x)
{
    return x + 3376990857U;
}

void setval_121(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_131()
{
    return 3286270280U;
}

void setval_375(unsigned *p)
{
    *p = 3527988873U;
}

unsigned getval_117()
{
    return 3281046153U;
}

unsigned addval_420(unsigned x)
{
    return x + 3525367433U;
}

unsigned getval_257()
{
    return 3380923021U;
}

unsigned getval_304()
{
    return 3286272328U;
}

unsigned addval_492(unsigned x)
{
    return x + 3286272328U;
}

void setval_105(unsigned *p)
{
    *p = 3286280520U;
}

unsigned getval_248()
{
    return 3525364353U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
